/**
********************************************************************************
\file   stdafx.cpp

\brief  Standard pre-compiled source file

This is a tool generated file to generate pre-compiled headers.

- stdafx.cpp : source file that includes just the standard includes
- notifyObj.pch will be the pre-compiled header
- stdafx.obj will contain the pre-compiled type information

*******************************************************************************/

 #include "stdafx.h"
