Revision {#revision}
========

- [FEATURE] Add documentation for parallel interface ipcore
- [FIX] Fix parallel bus interface timing diagram
- [TASK] Clean up axi host interface ipcore
- [FIX] Fix parallel slave ALE input
- [TASK] Remove synchronizers for readdata path in prlMaster
- [TASK] Revise host interface documentation
- [FIX] Fix parallel slave for odd address/data width
- [FEATURE] Revise parallel interface for static timing
- [FEATURE] Enable Demux and Mux modes in parallel interface ipcores
- [FIX] Rename mpx* ipcores to prl*
